<?php
// created: 2009-11-04 09:18:39
$mod_strings = array (
  'LBL_COST_PRICE' => 'CPM',
  'LBL_LIST_PRICE' => 'Cost Per Month',
  'LBL_DISCOUNT_PRICE' => '1 Month Total Cost',
  'LBL_QUANTITY' => 'Months',
  'LBL_LIST_QUANTITY' => 'Months',
);
?>
