<?php 
 //WARNING: The contents of this file are auto-generated


$mod_strings [ "LBL_ACCOUNTS_ACCOUNTS_FROM_ACCOUNTS_L_TITLE" ] = "Accounts" ;
$mod_strings [ "LBL_ACCOUNTS_ACCOUNTS_FROM_ACCOUNTS_R_TITLE" ] = "Accounts" ;

?>