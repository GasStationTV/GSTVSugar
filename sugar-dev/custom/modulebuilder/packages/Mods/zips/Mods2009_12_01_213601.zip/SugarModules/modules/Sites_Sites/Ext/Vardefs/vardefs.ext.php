<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2009-08-12 08:47:50
$dictionary["Sites_Sites"]["fields"]["sites_sites_cases"] = array (
  'name' => 'sites_sites_cases',
  'type' => 'link',
  'relationship' => 'sites_sites_cases',
  'source' => 'non-db',
);


// created: 2009-08-12 12:16:32
$dictionary["Sites_Sites"]["fields"]["sites_sites_cases"] = array (
  'name' => 'sites_sites_cases',
  'type' => 'link',
  'relationship' => 'sites_sites_cases',
  'source' => 'non-db',
);


// created: 2009-08-13 09:04:43
$dictionary["Sites_Sites"]["fields"]["sites_sites_cases"] = array (
  'name' => 'sites_sites_cases',
  'type' => 'link',
  'relationship' => 'sites_sites_cases',
  'source' => 'non-db',
);


// created: 2009-08-13 12:36:03
$dictionary["Sites_Sites"]["fields"]["sites_sites_cases"] = array (
  'name' => 'sites_sites_cases',
  'type' => 'link',
  'relationship' => 'sites_sites_cases',
  'source' => 'non-db',
);


// created: 2009-08-14 08:09:17
$dictionary["Sites_Sites"]["fields"]["sites_sites_cases"] = array (
  'name' => 'sites_sites_cases',
  'type' => 'link',
  'relationship' => 'sites_sites_cases',
  'source' => 'non-db',
);


// created: 2009-08-14 08:09:18
$dictionary["Sites_Sites"]["fields"]["sites_basic_test_sites_sites"] = array (
  'name' => 'sites_basic_test_sites_sites',
  'type' => 'link',
  'relationship' => 'sites_basic_test_sites_sites',
  'source' => 'non-db',
);


// created: 2009-08-14 08:17:07
$dictionary["Sites_Sites"]["fields"]["sites_sites_cases"] = array (
  'name' => 'sites_sites_cases',
  'type' => 'link',
  'relationship' => 'sites_sites_cases',
  'source' => 'non-db',
);


// created: 2009-08-14 08:17:07
$dictionary["Sites_Sites"]["fields"]["sites_basic_test_sites_sites"] = array (
  'name' => 'sites_basic_test_sites_sites',
  'type' => 'link',
  'relationship' => 'sites_basic_test_sites_sites',
  'source' => 'non-db',
);


// created: 2009-09-01 07:13:39
$dictionary["Sites_Sites"]["fields"]["sites_sites_cases"] = array (
  'name' => 'sites_sites_cases',
  'type' => 'link',
  'relationship' => 'sites_sites_cases',
  'source' => 'non-db',
);


// created: 2009-09-01 08:29:30
$dictionary["Sites_Sites"]["fields"]["sites_sites_cases"] = array (
  'name' => 'sites_sites_cases',
  'type' => 'link',
  'relationship' => 'sites_sites_cases',
  'source' => 'non-db',
);



// created: 2009-09-11 08:02:11
$dictionary["Sites_Sites"]["fields"]["sites_sites_cases"] = array (
  'name' => 'sites_sites_cases',
  'type' => 'link',
  'relationship' => 'sites_sites_cases',
  'source' => 'non-db',
);


// created: 2009-11-24 15:23:21
$dictionary["Sites_Sites"]["fields"]["sites_sites_cases"] = array (
  'name' => 'sites_sites_cases',
  'type' => 'link',
  'relationship' => 'sites_sites_cases',
  'source' => 'non-db',
  'vname' => 'LBL_SITES_SITES_CASES_FROM_CASES_TITLE',
);


?>