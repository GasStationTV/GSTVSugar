<?php
// created: 2009-09-22 08:30:37
$mod_strings = array (
  'VALUE' => 'Assigned to:',
  'LBL_HISTORY' => 'History',
  'LBL_DESCRIPTION' => 'GSTV History/Notes:',
  'LBL_JOB_FUNCTION' => 'Job Function',
  'LBL_CONTACT_COMPANY' => 'Contact Company',
  'LBL_JOB_TITLE' => 'Job Title',
  'LBL_BUSINESS_PHONE_2' => 'Business Phone 2',
  'LBL_COMPANY_MAIN_PHONE' => 'Company Main Phone',
  'LBL_EMAIL_2' => 'Email 2',
  'LBL_ASSIGNED_TO_EMPLOYEE' => 'Assigned to:',
  'LBL_ASSIGNED_TO_NAME' => 'Assigned to (User):',
);
?>
