<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2009-08-12 08:47:50
$layout_defs["Sites_Sites"]["subpanel_setup"]["sites_sites_cases"] = array (
  'order' => 100,
  'module' => 'Cases',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SITES_SITES_CASES_FROM_CASES_TITLE',
  'get_subpanel_data' => 'sites_sites_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Cases',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-08-12 12:16:32
$layout_defs["Sites_Sites"]["subpanel_setup"]["sites_sites_cases"] = array (
  'order' => 100,
  'module' => 'Cases',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SITES_SITES_CASES_FROM_CASES_TITLE',
  'get_subpanel_data' => 'sites_sites_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Cases',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-08-13 09:04:43
$layout_defs["Sites_Sites"]["subpanel_setup"]["sites_sites_cases"] = array (
  'order' => 100,
  'module' => 'Cases',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SITES_SITES_CASES_FROM_CASES_TITLE',
  'get_subpanel_data' => 'sites_sites_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Cases',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-08-13 12:36:03
$layout_defs["Sites_Sites"]["subpanel_setup"]["sites_sites_cases"] = array (
  'order' => 100,
  'module' => 'Cases',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SITES_SITES_CASES_FROM_CASES_TITLE',
  'get_subpanel_data' => 'sites_sites_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Cases',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-08-14 08:09:17
$layout_defs["Sites_Sites"]["subpanel_setup"]["sites_sites_cases"] = array (
  'order' => 100,
  'module' => 'Cases',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SITES_SITES_CASES_FROM_CASES_TITLE',
  'get_subpanel_data' => 'sites_sites_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Cases',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-08-14 08:09:18
$layout_defs["Sites_Sites"]["subpanel_setup"]["sites_basic_test_sites_sites"] = array (
  'order' => 100,
  'module' => 'Sites_Basic_Test',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SITES_BASIC_TEST_SITES_SITES_FROM_SITES_BASIC_TEST_TITLE',
  'get_subpanel_data' => 'sites_basic_test_sites_sites',
);


// created: 2009-08-14 08:17:07
$layout_defs["Sites_Sites"]["subpanel_setup"]["sites_sites_cases"] = array (
  'order' => 100,
  'module' => 'Cases',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SITES_SITES_CASES_FROM_CASES_TITLE',
  'get_subpanel_data' => 'sites_sites_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Cases',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-08-14 08:17:07
$layout_defs["Sites_Sites"]["subpanel_setup"]["sites_basic_test_sites_sites"] = array (
  'order' => 100,
  'module' => 'Sites_Basic_Test',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SITES_BASIC_TEST_SITES_SITES_FROM_SITES_BASIC_TEST_TITLE',
  'get_subpanel_data' => 'sites_basic_test_sites_sites',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Sites_Basic_Test',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-09-01 07:13:39
$layout_defs["Sites_Sites"]["subpanel_setup"]["sites_sites_cases"] = array (
  'order' => 100,
  'module' => 'Cases',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SITES_SITES_CASES_FROM_CASES_TITLE',
  'get_subpanel_data' => 'sites_sites_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Cases',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-09-01 08:29:30
$layout_defs["Sites_Sites"]["subpanel_setup"]["sites_sites_cases"] = array (
  'order' => 100,
  'module' => 'Cases',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SITES_SITES_CASES_FROM_CASES_TITLE',
  'get_subpanel_data' => 'sites_sites_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Cases',
      'mode' => 'MultiSelect',
    ),
  ),
);



// created: 2009-09-11 08:02:11
$layout_defs["Sites_Sites"]["subpanel_setup"]["sites_sites_cases"] = array (
  'order' => 100,
  'module' => 'Cases',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SITES_SITES_CASES_FROM_CASES_TITLE',
  'get_subpanel_data' => 'sites_sites_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Cases',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-11-24 15:23:21
$layout_defs["Sites_Sites"]["subpanel_setup"]["sites_sites_cases"] = array (
  'order' => 100,
  'module' => 'Cases',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SITES_SITES_CASES_FROM_CASES_TITLE',
  'get_subpanel_data' => 'sites_sites_cases',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Cases',
      'mode' => 'MultiSelect',
    ),
  ),
);


?>