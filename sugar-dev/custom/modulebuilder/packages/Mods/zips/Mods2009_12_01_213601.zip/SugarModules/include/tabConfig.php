<?php
// created: 2009-11-06 10:39:32
$GLOBALS['tabStructure'] = array (
  'LBL_TABGROUP_HOME' => 
  array (
    'label' => 'LBL_TABGROUP_HOME',
    'modules' => 
    array (
      0 => 'Home',
      1 => 'Dashboard',
    ),
  ),
  'LBL_TABGROUP_SALES' => 
  array (
    'label' => 'LBL_TABGROUP_SALES',
    'modules' => 
    array (
      0 => 'Accounts',
      1 => 'Opportunities',
      2 => 'Leads',
      3 => 'Contracts',
      4 => 'Quotes',
      5 => 'Products',
      6 => 'Contacts',
      7 => 'Forecasts',
    ),
  ),
  'LBL_TABGROUP_MARKETING' => 
  array (
    'label' => 'LBL_TABGROUP_MARKETING',
    'modules' => 
    array (
      0 => 'Campaigns',
      1 => 'Contacts',
      2 => 'Accounts',
      3 => 'Leads',
    ),
  ),
  'LBL_TABGROUP_SUPPORT' => 
  array (
    'label' => 'LBL_TABGROUP_SUPPORT',
    'modules' => 
    array (
      0 => 'Cases',
      1 => 'Bugs',
      2 => 'Accounts',
      3 => 'Contacts',
      4 => 'Products',
      5 => 'KBDocuments',
    ),
  ),
  'LBL_TABGROUP_ACTIVITIES' => 
  array (
    'label' => 'LBL_TABGROUP_ACTIVITIES',
    'modules' => 
    array (
      0 => 'Activities',
      1 => 'Calendar',
      2 => 'Emails',
      3 => 'Calls',
      4 => 'Meetings',
      5 => 'Tasks',
      6 => 'Notes',
    ),
  ),
  'LBL_TABGROUP_COLLABORATION' => 
  array (
    'label' => 'LBL_TABGROUP_COLLABORATION',
    'modules' => 
    array (
      0 => 'Emails',
      1 => 'Project',
      2 => 'Documents',
    ),
  ),
  'LBL_TABGROUP_TOOLS' => 
  array (
    'label' => 'LBL_TABGROUP_TOOLS',
    'modules' => 
    array (
      0 => 'Feeds',
      1 => 'iFrames',
    ),
  ),
  'LBL_TABGROUP_REPORTS' => 
  array (
    'label' => 'LBL_TABGROUP_REPORTS',
    'modules' => 
    array (
      0 => 'Reports',
      1 => 'Dashboard',
    ),
  ),
  'LBL_TABGROUP_OTHER' => 
  array (
    'label' => 'LBL_TABGROUP_OTHER',
    'modules' => 
    array (
      0 => 'Sites_Sites',
      1 => 'Sites_Site_Database_Test1',
      2 => 'Sites_Site_Module',
    ),
  ),
);
?>
