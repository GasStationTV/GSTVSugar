<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2009-08-14 08:43:32
$dictionary["Account"]["fields"]["accounts_accounts"] = array (
  'name' => 'accounts_accounts',
  'type' => 'link',
  'relationship' => 'accounts_accounts',
  'source' => 'non-db',
);


// created: 2009-08-14 08:43:32
$dictionary["Account"]["fields"]["accounts_accounts"] = array (
  'name' => 'accounts_accounts',
  'type' => 'link',
  'relationship' => 'accounts_accounts',
  'source' => 'non-db',
);


?>