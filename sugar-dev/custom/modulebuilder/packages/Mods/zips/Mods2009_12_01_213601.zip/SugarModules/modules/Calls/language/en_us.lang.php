<?php
// created: 2009-11-09 14:00:11
$mod_strings = array (
  'VALUE' => 'Purpose',
  'LBL_LEIDER' => 'Leider to Attend?',
  'LBL_PURPOSE' => 'Purpose',
);
?>
