<?php
$searchdefs ['Accounts'] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'label' => 'LBL_NAME',
        'default' => true,
      ),
      'phone_office' => 
      array (
        'name' => 'phone_office',
        'label' => 'LBL_PHONE_OFFICE',
        'default' => true,
      ),
      'segment_c' => 
      array (
        'width' => '10%',
        'label' => 'LBL_SEGMENT',
        'default' => true,
        'name' => 'segment_c',
      ),
      'address_street' => 
      array (
        'name' => 'address_street',
        'label' => 'LBL_BILLING_ADDRESS',
        'type' => 'name',
        'group' => 'billing_address_street',
        'default' => true,
      ),
      'billing_address_city' => 
      array (
        'name' => 'billing_address_city',
        'label' => 'LBL_BILLING_ADDRESS_CITY',
        'default' => true,
      ),
      'current_user_only' => 
      array (
        'name' => 'current_user_only',
        'label' => 'LBL_CURRENT_USER_FILTER',
        'type' => 'bool',
        'default' => true,
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'label' => 'LBL_NAME',
        'default' => true,
      ),
      'address_street' => 
      array (
        'name' => 'address_street',
        'label' => 'LBL_ANY_ADDRESS',
        'type' => 'name',
        'default' => true,
      ),
      'phone' => 
      array (
        'name' => 'phone',
        'label' => 'LBL_ANY_PHONE',
        'type' => 'name',
        'default' => true,
      ),
      'website' => 
      array (
        'name' => 'website',
        'label' => 'LBL_WEBSITE',
        'default' => true,
      ),
      'dma_c' => 
      array (
        'width' => '10%',
        'label' => 'LBL_DMA',
        'default' => true,
        'name' => 'dma_c',
      ),
      'annual_revenue' => 
      array (
        'name' => 'annual_revenue',
        'label' => 'LBL_ANNUAL_REVENUE',
        'default' => true,
      ),
      'address_city' => 
      array (
        'name' => 'address_city',
        'label' => 'LBL_CITY',
        'type' => 'name',
        'default' => true,
      ),
      'address_state' => 
      array (
        'name' => 'address_state',
        'label' => 'LBL_STATE',
        'type' => 'name',
        'default' => true,
      ),
      'address_postalcode' => 
      array (
        'name' => 'address_postalcode',
        'label' => 'LBL_POSTAL_CODE',
        'type' => 'name',
        'default' => true,
      ),
      'billing_address_country' => 
      array (
        'name' => 'billing_address_country',
        'label' => 'LBL_COUNTRY',
        'type' => 'name',
        'options' => 'countries_dom',
        'default' => true,
      ),
      'ticker_symbol' => 
      array (
        'name' => 'ticker_symbol',
        'label' => 'LBL_TICKER_SYMBOL',
        'default' => true,
      ),
      'assigned_user_name' => 
      array (
        'width' => '10%',
        'label' => 'LBL_ASSIGNED_TO_NAME',
        'default' => true,
        'name' => 'assigned_user_name',
      ),
      'category_c' => 
      array (
        'width' => '10%',
        'label' => 'LBL_CATEGORY',
        'default' => true,
        'name' => 'category_c',
      ),
      'subcategory_c' => 
      array (
        'width' => '10%',
        'label' => 'LBL_SUBCATEGORY',
        'default' => true,
        'name' => 'subcategory_c',
      ),
      'parent_name' => 
      array (
        'width' => '10%',
        'label' => 'LBL_MEMBER_OF',
        'default' => true,
        'name' => 'parent_name',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
