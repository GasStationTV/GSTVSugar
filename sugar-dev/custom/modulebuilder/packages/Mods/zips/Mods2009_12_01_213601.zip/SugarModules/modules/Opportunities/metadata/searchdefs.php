<?php
$searchdefs ['Opportunities'] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'label' => 'LBL_OPPORTUNITY_NAME',
        'default' => true,
        'width' => '10%',
      ),
      'opportunity_type' => 
      array (
        'name' => 'opportunity_type',
        'label' => 'LBL_TYPE',
        'default' => true,
        'width' => '50%',
      ),
      'gstv_dmas_c' => 
      array (
        'width' => '10%',
        'label' => 'LBL_GSTV_DMAS',
        'default' => true,
        'name' => 'gstv_dmas_c',
      ),
      'current_user_only' => 
      array (
        'name' => 'current_user_only',
        'label' => 'LBL_CURRENT_USER_FILTER',
        'type' => 'bool',
        'default' => true,
        'width' => '50%',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'label' => 'LBL_OPPORTUNITY_NAME',
        'default' => true,
      ),
      'flight_start_date_c' => 
      array (
        'width' => '10%',
        'label' => 'LBL_FLIGHT_START_DATE',
        'default' => true,
        'name' => 'flight_start_date_c',
      ),
      'flight_end_date_c' => 
      array (
        'width' => '10%',
        'label' => 'LBL_FLIGHT_END_DATE',
        'default' => true,
        'name' => 'flight_end_date_c',
      ),
      'subcategory_c' => 
      array (
        'width' => '10%',
        'label' => 'LBL_SUBCATEGORY',
        'default' => true,
        'name' => 'subcategory_c',
      ),
      'gstv_dmas_c' => 
      array (
        'width' => '10%',
        'label' => 'LBL_GSTV_DMAS',
        'default' => true,
        'name' => 'gstv_dmas_c',
      ),
      'amount' => 
      array (
        'name' => 'amount',
        'label' => 'LBL_AMOUNT',
        'default' => true,
        'currency_format' => true,
      ),
      'account_name' => 
      array (
        'name' => 'account_name',
        'label' => 'LBL_ACCOUNT_NAME',
        'default' => true,
      ),
      'primary_account_type_c' => 
      array (
        'width' => '10%',
        'label' => 'LBL_PRIMARY_ACCOUNT_TYPE',
        'default' => true,
        'name' => 'primary_account_type_c',
      ),
      'brand_c' => 
      array (
        'width' => '10%',
        'label' => 'LBL_BRAND',
        'default' => true,
        'name' => 'brand_c',
      ),
      'account_name_2_c' => 
      array (
        'width' => '10%',
        'label' => 'LBL_ACCOUNT_NAME_2',
        'default' => true,
        'name' => 'account_name_2_c',
      ),
      'related_account_2_type_c' => 
      array (
        'width' => '10%',
        'label' => 'LBL_RELATED_ACCOUNT_2_TYPE',
        'default' => true,
        'name' => 'related_account_2_type_c',
      ),
      'product_c' => 
      array (
        'width' => '10%',
        'label' => 'LBL_PRODUCT',
        'default' => true,
        'name' => 'product_c',
      ),
      'account_name_3_c' => 
      array (
        'width' => '10%',
        'label' => 'LBL_ACCOUNT_NAME_3',
        'default' => true,
        'name' => 'account_name_3_c',
      ),
      'related_account_3_type_c' => 
      array (
        'width' => '10%',
        'label' => 'LBL_RELATED_ACCOUNT_3_TYPE',
        'default' => true,
        'name' => 'related_account_3_type_c',
      ),
      'lead_source' => 
      array (
        'name' => 'lead_source',
        'label' => 'LBL_LEAD_SOURCE',
        'default' => true,
      ),
      'sales_stage' => 
      array (
        'name' => 'sales_stage',
        'label' => 'LBL_SALES_STAGE',
        'default' => true,
      ),
      'assigned_user_name' => 
      array (
        'width' => '10%',
        'label' => 'LBL_ASSIGNED_TO_NAME',
        'default' => true,
        'name' => 'assigned_user_name',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
