<?php 
 //WARNING: The contents of this file are auto-generated


$mod_strings [ "LBL_SITES_SITES_CASES_FROM_CASES_TITLE" ] = "Cases" ;
$mod_strings [ "LBL_SITES_SITES_CASES_FROM_CASES_TITLE" ] = "Cases" ;
$mod_strings [ "LBL_SITES_SITES_CASES_FROM_CASES_TITLE" ] = "Cases" ;
$mod_strings [ "LBL_SITES_SITES_CASES_FROM_CASES_TITLE" ] = "Cases" ;
$mod_strings [ "LBL_SITES_SITES_CASES_FROM_CASES_TITLE" ] = "Cases" ;
$mod_strings [ "LBL_SITES_BASIC_TEST_SITES_SITES_FROM_SITES_BASIC_TEST_TITLE" ] = "Test Module" ;
$mod_strings [ "LBL_SITES_SITES_CASES_FROM_CASES_TITLE" ] = "Cases" ;
$mod_strings [ "LBL_SITES_BASIC_TEST_SITES_SITES_FROM_SITES_BASIC_TEST_TITLE" ] = "Test Module" ;
$mod_strings [ "LBL_SITES_SITES_CASES_FROM_CASES_TITLE" ] = "Cases" ;
$mod_strings [ "LBL_SITES_SITES_CASES_FROM_CASES_TITLE" ] = "Cases" ;


$mod_strings [ "LBL_SITES_SITES_CASES_FROM_CASES_TITLE" ] = "Cases" ;
$mod_strings [ "LBL_SITES_SITES_CASES_FROM_CASES_TITLE" ] = "Cases" ;

?>