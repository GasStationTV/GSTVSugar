<?php
 // created: 2013-08-03 10:21:49
$layout_defs["Opportunities"]["subpanel_setup"]['props_proposals_opportunities'] = array (
  'order' => 100,
  'module' => 'props_Proposals',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_PROPS_PROPOSALS_OPPORTUNITIES_FROM_PROPS_PROPOSALS_TITLE',
  'get_subpanel_data' => 'props_proposals_opportunities',
);
