<?php
// created: 2013-08-03 10:21:49
$dictionary["Opportunity"]["fields"]["props_proposals_opportunities"] = array (
  'name' => 'props_proposals_opportunities',
  'type' => 'link',
  'relationship' => 'props_proposals_opportunities',
  'source' => 'non-db',
  'module' => 'props_Proposals',
  'bean_name' => false,
  'vname' => 'LBL_PROPS_PROPOSALS_OPPORTUNITIES_FROM_PROPS_PROPOSALS_TITLE',
);
