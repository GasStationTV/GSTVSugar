<?php
 // created: 2013-08-03 10:21:49
$layout_defs["props_Proposals"]["subpanel_setup"]['props_proposals_opportunities'] = array (
  'order' => 100,
  'module' => 'Opportunities',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_PROPS_PROPOSALS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'get_subpanel_data' => 'props_proposals_opportunities',
);
