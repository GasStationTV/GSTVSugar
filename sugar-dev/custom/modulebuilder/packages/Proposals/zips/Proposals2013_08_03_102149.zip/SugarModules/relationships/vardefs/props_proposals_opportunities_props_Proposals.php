<?php
// created: 2013-08-03 10:21:49
$dictionary["props_Proposals"]["fields"]["props_proposals_opportunities"] = array (
  'name' => 'props_proposals_opportunities',
  'type' => 'link',
  'relationship' => 'props_proposals_opportunities',
  'source' => 'non-db',
  'module' => 'Opportunities',
  'bean_name' => 'Opportunity',
  'vname' => 'LBL_PROPS_PROPOSALS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
);
